public class Computadoras_objetos {

    public static void main (String[] args){

        Computadoras computadora1=new Computadoras("HP","Intel",10);
        Computadoras computadora2=new Computadoras("Mac","A11",2021);
        Computadoras computadora3=new Computadoras("Gama alta","Intel",11);
        System.out.println(computadora1.toString());
        System.out.println(computadora2.toString());
        System.out.println(computadora3.toString());
    }
}
