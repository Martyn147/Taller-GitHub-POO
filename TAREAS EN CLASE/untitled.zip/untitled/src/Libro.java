public class Libro {

    //Crearemos atributos
    private int ISBN;
    private String titulo;
    private  String autor;
    private  String genero;
    private  int anio;
    private  String pais;
    private  int numPaginas;
    private String editorial;
    //Fin de atributos;

    //Crearemos Contructores

    public Libro( int pISBN,
    String ptitulo,
    String pautor,
    String pgenero,
    int panio,
    String ppais,
    int pnumPaginas,
    String peditorial){

        ISBN=pISBN;
        titulo=ptitulo;
        autor=pautor;
        genero=pgenero;
        anio=panio;
        pais=ppais;
        numPaginas=pnumPaginas;
        editorial=peditorial;

    }
    //Fin contructores

    //Métodos setter y getters

    public int getISBN() {
        return ISBN;
    }

    public void setISBN(int ISBN) {
        this.ISBN = ISBN;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public int getNumPaginas() {
        return numPaginas;
    }

    public void setNumPaginas(int numPaginas) {
        this.numPaginas = numPaginas;
    }

    public String getEditorial() {
        return editorial;
    }

    public void setEditorial(String editorial) {
        this.editorial = editorial;
    }


    //Fin métodos setter y getters

    /*Método*/

    @Override
    public String toString(){
     return "El libro es "+titulo+" con iSBN "+ISBN+" y "+" creado por "+autor;
    }
    //fin métodos
}
