public class uno {

    public static void main (String [] args){


        Libro libro1=new Libro(123456,"Cumanda","Juan","terror",2021,"Ecuador",235,"Amazonas");

        Libro libro2=new Libro(1235,"YoloAventuras","Yolo","Comedia",2019,"Costa Rica", 74156,"Argentina");
            System.out.println(libro1.toString());

        System.out.println(libro2.toString());



    }
}
