public class Visual {
    private int nentero;
    private short nShort;
    private byte nByte;
    private long nLong;
    private float nFloat;
    private  double nDouble;

    public Visual(int nentero, short nShort, byte nByte, long nLong, float nFloat, double nDouble) {
        this.nentero = nentero;
        this.nShort = nShort;
        this.nByte = nByte;
        this.nLong = nLong;
        this.nFloat = nFloat;
        this.nDouble = nDouble;
    }

    public int getNentero() {
        return nentero;
    }

    public void setNentero(int nentero) {
        this.nentero = nentero;
    }

    public short getnShort() {
        return nShort;
    }

    public void setnShort(short nShort) {
        this.nShort = nShort;
    }

    public byte getnByte() {
        return nByte;
    }

    public void setnByte(byte nByte) {
        this.nByte = nByte;
    }

    public long getnLong() {
        return nLong;
    }

    public void setnLong(long nLong) {
        this.nLong = nLong;
    }

    public float getnFloat() {
        return nFloat;
    }

    public void setnFloat(float nFloat) {
        this.nFloat = nFloat;
    }

    public double getnDouble() {
        return nDouble;
    }

    public void setnDouble(double nDouble) {
        this.nDouble = nDouble;
    }

    public void CasteoDatos(){


    }
}
