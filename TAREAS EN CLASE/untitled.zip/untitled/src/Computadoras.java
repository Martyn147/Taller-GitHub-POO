public class Computadoras {

    //Atributos

    private String marca;
    private String tipo;
    private int generación;

    //creamos constructores

    public Computadoras(String pmarca,String ptipo,int pgeneración){

        marca=pmarca;
        tipo=ptipo;
        generación=pgeneración;
    }

    //setter y getter


    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getGeneración() {
        return generación;
    }

    public void setGeneración(int generación) {
        this.generación = generación;
    }

    /*método*/

    @Override
    public String toString(){

        return "La computadora "+marca+" con procesador "+tipo+" de "+generación+"va generacion";
    }
}
